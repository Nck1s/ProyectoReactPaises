import React from 'react'

const Juego = () => {
  return (
    <div>juego</div>
  )
}

export default Juego