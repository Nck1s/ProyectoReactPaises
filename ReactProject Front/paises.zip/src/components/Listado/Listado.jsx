import React from 'react'

const Listado = () => {
  return (
    <div>Listado</div>
  )
}

export default Listado