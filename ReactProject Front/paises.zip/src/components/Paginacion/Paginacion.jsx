import React from 'react'

const Paginacion = () => {
  return (
    <div>Paginacion</div>
  )
}

export default Paginacion